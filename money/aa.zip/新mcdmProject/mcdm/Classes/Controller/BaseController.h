//
//  BaseController.h
//  MCDM
//
//  Created by Fred on 12-12-27.
//  Copyright (c) 2012年 Fred. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseController : UIViewController
{
    
}

- (void)onRefresh;

@end
