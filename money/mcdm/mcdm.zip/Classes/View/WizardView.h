

#import "PredictScrollView.h"


//
@interface WizardView : PageControlScrollView <PredictScrollViewDelegate>
{
	NSArray *_images;
}
@end
