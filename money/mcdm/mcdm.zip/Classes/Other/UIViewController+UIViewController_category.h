//
//  UIViewController+UIViewController_category.h
//  MCDM
//
//  Created by Fred on 13-1-1.
//  Copyright (c) 2013年 Fred. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (UIViewController_category)

- (void)popSelf;
- (NSString *)iconImageName;

@end
